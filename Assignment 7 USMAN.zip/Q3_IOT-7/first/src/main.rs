use first::code::chunk;

fn main(){
println!("{:?}", chunk::msg());
}